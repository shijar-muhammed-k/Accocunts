from django.shortcuts import render
from django.shortcuts import render,redirect
from .forms import *
from django.contrib import messages
from django.http import HttpResponse,HttpResponseRedirect
from .models import *
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,logout

# Create your views here.
def register(request):
    if request.method =='POST':
        name=request.POST.get('name')
        username=request.POST.get('username')
        email=request.POST.get('email')
        password=request.POST.get('password')
    
        obj=User.objects.create_user(username=username,password=password,email=email)
        Customer.objects.create(name=name,username=username,password=password,email=email)
        return redirect('login')
    else:
        return render(request,'customerregister.html')
    
def ownerregister(request):
    if request.method=="POST":
        name=request.POST.get('name')
        username=request.POST.get('username')
        password=request.POST.get('password')

        obj=User.objects.create_user(username=username,password=password)
        Owner.objects.create(name=name,username=username,password=password)
        return HttpResponse('done')
    else:
        return render(request,'ownerregister.html')
    
def login(request):
    if request.method=='POST':
        a=request.POST.get('username')
        b=request.POST.get('password')
        ob=Customer.objects.get(username=a)
        user=authenticate(username=a,password=b)
        print(user)
        print(ob.user_type)
        if user is not None:
            if ob.user_type=='customer':
                request.session['username'] =  a
                my_value = request.session.get('username')
                print(my_value)

                return redirect('home')
            else:
                print(user)
                return HttpResponse('done')
            #    return render(request,'ownerlogin.html',{'user':user})
                
        else:
           print("invalid username password")
    return render(request,'login.html')
def logout_user(request):
    logout(request)
    return redirect('login')

def search_hotel(request):
    name = request.GET.get('name')
    country = request.GET.get('country')
    rating = request.GET.get('rating')
#  Start with a base query that selects all objects
    query = Hotel.objects.all()
#  Apply filters based on input values
    if name:
        query = query.filter(name__icontains=name)
    if country:
        query = query.filter(location__icontains=country)
    if rating:
        query = query.filter(rating=rating)

    # Execute the final query
    results = query.all()


    return render(request, 'search_result.html', {'results': results})
def loginedhome(request):
    return redirect('home')

def home(request):
    template_name='cutomerlogin.html'
    my_value = request.session.get('username')
    print(my_value)
    ho_list=Hotel.objects.all()
    context={'ho_list':ho_list,'user':my_value}
    return render(request,template_name,context)

def hotel_add(request):
    if request.method=='POST':
        form=HotelForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            template_name='cutomerlogin.html'
            ho_list=Hotel.objects.all()
            context={'ho_list':ho_list}
            return render(request,template_name,context)
    else:
        form=HotelForm()
    context={'form':form}
    return render(request,'hotel_add.html',context)

def product_detail(request,pk):
    template_name=('productdetail.html')
    pro_de=Hotel.objects.get(id=pk)
    context={'pro_de':pro_de}
    return render(request,template_name,context)

def add_to_cart(request, hotel_id):
    hotel = get_object_or_404(Hotel, pk=hotel_id)
    cart, created = Cart.objects.get_or_create()
    cart_hotel, created = CartHotel.objects.get_or_create(cart=cart, hotel=hotel)
    
    if not created:
        cart_hotel.quantity += 1
        cart_hotel.save()
    
    return redirect('cart')

def cart(request):
    cart = Cart.objects.first()
    cart_hotels = cart.carthotel_set.all() if cart else []
    
    return render(request, 'cart.html', {'cart_hotels': cart_hotels})

def add_to_favorites(request, hotel_id):
    hotel = get_object_or_404(Hotel, pk=hotel_id)
    favorite, created = Favorite.objects.get_or_create(user=request.user)
    FavoriteHotel.objects.get_or_create(favorite=favorite, hotel=hotel)
    
    return redirect('favorites')

def favorites(request):
    favorite = Favorite.objects.filter(user=request.user).first()
    favorite_hotels = favorite.favoritehotel_set.all() if favorite else []
    
    return render(request, 'favorites.html', {'favorite_hotels': favorite_hotels})


def add_to_save_for_later(request, hotel_id):
    hotel = get_object_or_404(Hotel, pk=hotel_id)
    favorite, created = Favorite.objects.get_or_create(user=request.user)
    FavoriteHotel.objects.get_or_create(favorite=favorite, hotel=hotel)
    
    return redirect('favorites')

def save_for_later(request):
    favorite = Favorite.objects.filter(user=request.user).first()
    favorite_hotels = favorite.favoritehotel_set.all() if favorite else []
    
    return render(request, 'favorites.html', {'favorite_hotels': favorite_hotels})