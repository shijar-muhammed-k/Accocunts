from django.contrib import admin
from django.urls import path,include
from .views import *

urlpatterns = [
    path('register/',register, name='register'),
    path('ownerregister/',ownerregister, name='ownerregister'),
    path('login/',login, name='login'),
    path('logout_user',logout_user,name='logout_user'),

    path('search_hotel/',search_hotel, name='search_hotel'),
    path('home', home, name='home'),
    path('', loginedhome, name='loginedhome'),

    path('hotel_add/', hotel_add, name='hotel_add'),
    path('product-detail/<int:pk>', product_detail, name='product-detail'),

    path('add_cart/<int:hotel_id>', add_to_cart, name='add_to_cart'),
    path('cart/', cart, name='cart'),

    path('add_to_favorites/<int:hotel_id>/',add_to_favorites, name='add_to_favorites'),
    path('favorites/',favorites, name='favorites'),

    path('add_to_save_for_later/<int:hotel_id>/',add_to_save_for_later, name='add_to_save_for_later'),
    path('save_for_later/',save_for_later, name='save_for_later'),
]
