# Create your models here.
from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator,MinValueValidator

class Customer(models.Model):
    name=models.CharField(max_length=200)
    username=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    password=models.CharField(max_length=100)
    user_type=models.CharField(max_length=200,default='customer')

    def __str__(self):
        return str(self.name)
    
class Owner(models.Model):
    name=models.CharField(max_length=200)
    username=models.CharField(max_length=200)
    password=models.CharField(max_length=100)

    
CATEGORY_CHOICES=(
    ('Luxury','luxury'),
    ('Mid-range','mid range'),
    ('Budget', 'budget'),
)

class Hotel(models.Model):
    name=models.CharField(max_length=100)
    location=models.CharField(max_length=100)
    rating=models.DecimalField(max_digits=3,decimal_places=1)
    price=models.IntegerField(default=True)
    category=models.CharField(choices=CATEGORY_CHOICES,max_length=15)
    product_image=models.ImageField(upload_to='productimg')

    def __str__(self):
        return str(self.name)


STATUS_CHOICES=(
    ('Accepted','Accepted'),
    ('Booked','Booked'),
    ('Cancel','Cancel'),)

class OrderPlaced(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    hotel=models.ForeignKey(Hotel, on_delete=models.CASCADE)
    ordered_date=models.DateTimeField(auto_now_add=True)
    status=models.CharField(max_length=50,choices=STATUS_CHOICES,default='pending')


class Cart(models.Model):
    hotels = models.ManyToManyField(Hotel, through='CartHotel')

class CartHotel(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    hotel = models.ForeignKey(Hotel, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
# Create your models here

class Wishlist(models.Model):
    user = models.ForeignKey(Customer, on_delete=models.CASCADE)
    products = models.ManyToManyField(Hotel)

class Favorite(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    hotels = models.ManyToManyField(Hotel, through='FavoriteHotel')

class FavoriteHotel(models.Model):
    favorite = models.ForeignKey(Favorite, on_delete=models.CASCADE)
    hotel = models.ForeignKey(Hotel, on_delete=models.CASCADE)


