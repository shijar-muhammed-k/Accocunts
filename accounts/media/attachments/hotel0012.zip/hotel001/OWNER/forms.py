from django import forms
from .models import *

class HotelForm(forms.ModelForm):
    class Meta:
        model=Hotel
        fields='__all__'

class CreateUserForm(forms.ModelForm):
    class Meta:
        model=Customer
        fields=['name','username','email','password']

class OwnerForm(forms.ModelForm):
    class Meta:
        model=Owner
        fields=['name','username','password']

